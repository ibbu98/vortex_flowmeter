/*
 * adc_data.h
 *
 *  Created on: Oct 31, 2025
 *      Author: IBRAHIM MUADH & VARUN SHAH
 */

#ifndef INC_ADC_DATA_H_
#define INC_ADC_DATA_H_

#include <stdint.h>


uint16_t adc_sample(void);


#endif /* INC_ADC_DATA_H_ */

